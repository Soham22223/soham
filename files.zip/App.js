import React, { useState, useEffect } from 'react';

function App() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');

  useEffect(() => {
    fetch('http://localhost:3001/tasks')
      .then(res => res.json())
      .then(setTasks);
  }, []);

  const addTask = async () => {
    const res = await fetch('http://localhost:3001/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, description: desc })
    });
    const newTask = await res.json();
    setTasks([...tasks, newTask]);
    setTitle('');
    setDesc('');
  };

  const completeTask = async (id) => {
    await fetch(`http://localhost:3001/tasks/${id}`, { method: 'PUT' });
    setTasks(tasks.map(t => t.id === id ? { ...t, completed: true } : t));
  };

  const deleteTask = async (id) => {
    await fetch(`http://localhost:3001/tasks/${id}`, { method: 'DELETE' });
    setTasks(tasks.filter(t => t.id !== id));
  };

  return (
    <div>
      <h1>Task Tracker</h1>
      <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Title" /><br/>
      <textarea value={desc} onChange={e => setDesc(e.target.value)} placeholder="Description" /><br/>
      <button onClick={addTask}>Add Task</button>
      <ul>
        {tasks.map(task =>
          <li key={task.id}>
            <b>{task.title}</b> - {task.description}
            {task.completed ? " (Completed)" : <button onClick={() => completeTask(task.id)}>Complete</button>}
            <button onClick={() => deleteTask(task.id)}>Delete</button>
          </li>
        )}
      </ul>
    </div>
  );
}

export default App;